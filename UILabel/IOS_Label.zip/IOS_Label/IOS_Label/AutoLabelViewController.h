//
//  AutoLabelViewController.h
//  IOS_Label
//
//  Created by Bc_Ltf on 15/4/7.
//  Copyright (c) 2015年 Bc_ltf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AutoLabelViewController : UIViewController
@property(nonatomic,strong)UILabel* titleLabel;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end
