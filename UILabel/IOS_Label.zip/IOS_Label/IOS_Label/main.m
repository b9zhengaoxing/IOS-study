//
//  main.m
//  IOS_Label
//
//  Created by Bc_Ltf on 15/4/7.
//  Copyright (c) 2015年 Bc_ltf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
