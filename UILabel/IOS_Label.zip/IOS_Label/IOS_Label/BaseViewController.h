//
//  BaseViewController.h
//  IOS_Label
//
//  Created by 李腾飞 on 16/6/1.
//  Copyright © 2016年 Bc_ltf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

//基础Label
@property(nonatomic,strong) UILabel * msgTipLabel;

//富文本
@property(nonatomic,strong) UILabel * richTextLabel;


@end
