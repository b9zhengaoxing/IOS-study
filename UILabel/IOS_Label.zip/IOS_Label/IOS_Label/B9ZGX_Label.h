//
//  B9ZGX_Label.h
//  IOS_Label
//
//  Created by Bc_Ltf on 15/4/9.
//  Copyright (c) 2015年 Bc_ltf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface B9ZGX_Label : UILabel

@end
